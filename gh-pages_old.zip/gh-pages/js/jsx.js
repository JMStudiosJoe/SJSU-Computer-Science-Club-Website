var Posts = React.createClass({
    render: function () {
        var converter = new showdown.Converter();
        var getTimeString = function (time) {
            if (time == "" || time == 0)
                return "Invalid Date";
            else if (time < 1000000000)
                time *= 1000;
            return (new Date(time)).toLocaleString();
        }
        var getAddressQuery = function (address, url) {
            if (address == "" && url)
                return "#";
            else if (address == "")
                return "";
            if (url)
                return "https://www.google.com/maps/search/" + address;
            else return address;
        }
        var rawMarkup = function(markdown) {
            return {__html: converter.makeHtml(markdown)};
        }
        var posts = this.props.all.map(function(post) {
            return <div><br/><br/>
                <div className={"card z-depth-4"}>
                    <div className={"card-image waves-effect waves-block waves-light"}>
                        <img src={post.image} />
                    </div>
                    <div className={"card-content"}>
                        <h4 className={"grey-text text-darken-4"}>{post.title}</h4>
                        <h5 className={"card-title grey-text text-darken-4"}>{post.summary}</h5>
                        <p className={"grey-text text-darken-4 flow-text"}>{getTimeString(post.eventTime)}</p>
                    </div>
                    <div className={"card-action"}>
                        <h5 className={"grey-text text-darken-4"}>
                                <a target={"_blank"} href={getAddressQuery(post.address, true)}>{getAddressQuery(post.address, false)}</a>
                        </h5>
                        <p className={"grey-text text-darken-4 flow-text"} dangerouslySetInnerHTML={rawMarkup(post.body.toString())} />
                    </div>
                </div>
            </div>;
        })
        return <div>{posts}</div>;
    }
});

var key;
var unsorted;
var keys;
var items;

firebase.database().ref('posts').on('value', function(snapshot) {
    for (key in snapshot.val()) {
        unsorted = snapshot.val()[key];
        keys = Object.keys(unsorted);
        items = [];
        for (var j = 0; j < keys.length; j++)
            items[j] = unsorted[keys[j]];
        ReactDOM.render( < Posts all = {
                items
            }
            / >,
            document.getElementById("r" + key));
    }

    cleanUp();
});


/*
<br><br>
<div class="card z-depth-4">
    <div class="card-image">
        <img src={tutor.image}>
    </div>
    <div class="card-content">

    <h4 class="grey-text text-darken-4">' + data[tutor].fname + " " + data[tutor].lname + '</h4><span class="card-title grey-text text-darken-4"><h5>' + data[tutor].title + '</h5></span></div><div class="card-action"><h5 class="grey-text text-darken-4"><a target="_blank" href="mailto:' + data[tutor].email + '">' + data[tutor].email + '</a></h5><p class="grey-text text-darken-4 flow-text">' + data[tutor].bio + '</p></div></div>'
*/