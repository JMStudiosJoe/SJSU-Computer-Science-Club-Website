var React = require('react');
var NavigationDiv = require("./navDiv");